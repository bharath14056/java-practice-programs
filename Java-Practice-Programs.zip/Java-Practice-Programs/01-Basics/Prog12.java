class prog12 
{
	public static void main(String[] args) 
	{
		System.out.println("Hello\\nWorld!");
	}
}
