class good
{
	public static void main(String[] args)
	{
       System.out.print("Java ");
       System.out.print("is ");
       System.out.print("Awesome");
	}
}